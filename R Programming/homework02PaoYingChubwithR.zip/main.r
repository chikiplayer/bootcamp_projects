fPaoYingChub <- function() {
  print("Welcome to Pao Ying Chub Game!!")
  print("----- Enter your name -----")
  name <- readLines("stdin", n=1)
  print(paste("Let's begin ",name, ":)"))

  # set variable
  win <- 0
  lose <- 0
  draw <- 0
  round <- 0
  replay <- as.character("Y")
  print("-------------------")
  print("GAME's RULES")
  print("1 = Paper")
  print("2 = Scissor")
  print("3 = Rock")
  print("Y = Replay")
  print("N = End Game")
  print("-------------------")
  

  while (replay == "Y") {
    round <- round + 1
    print("Your turn")  
    user_choice <- readLines("stdin", n = 1 )
    bot_choice <- sample(1:3, 1)
    if (user_choice == 1 & bot_choice == 1){
      print("draw")
      draw <- draw + 1
    } else if (user_choice == 1 & bot_choice == 2) {
        print("lose")
        lose <- lose + 1
    } else if (user_choice == 1 & bot_choice == 3) {
        print("win")
        win <- win + 1
    } else if (user_choice == 2 & bot_choice == 1) {
        print("win")
        win <- win + 1
    } else if (user_choice == 2 & bot_choice == 2) {
        print("draw")
        draw <- draw + 1
    } else if (user_choice == 2 & bot_choice == 3) {
        print("lose")
        lose <- lose + 1
    } else if (user_choice == 3 & bot_choice == 1) {
        print("lose")
        lose <- lose + 1
    } else if (user_choice == 3 & bot_choice == 2) {
        print("win")
        win <- win + 1
    } else if (user_choice == 3 & bot_choice == 3) {
        print("draw")
        draw <- draw + 1
    }
  print("play again ?")
  print("Y or N")
    # ASK TRY AGIAN?
  replay <- readLines ("stdin", n = 1)
  if (replay == "N") {
    print(paste(name, "Result"))
    print(paste("win:", win))
    print(paste("lose:", lose))
    print(paste("draw:", draw))
    print(paste("total game play:", round))
  }
}
}

fPaoYingChub()