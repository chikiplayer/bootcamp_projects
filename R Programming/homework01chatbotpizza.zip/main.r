# homework01
# Chatbot สั่ง Pizza มีอย่างน้อย 8-10 dialogues

#pizza_manu
##df_pizza
pizza_id <- as.numeric(c(1,2,3,4,5))
pizza <- c("Ham & Crab stick","Hawaiian","Pork Deluxe","Veggie","Double Pepporoni")
pizza_price <- c(10,14,17,22,24)

df_pizza <- data.frame(ID = pizza_id,
                       Menu = pizza,
                       Price = pizza_price)

pizza_size_id <- c(1,2,3)
pizza_size <- c("S","M","L")
pizza_size_prc <- c(0,2,4)

df_pizza_size <- data.frame(ID = pizza_size_id,
                           Size = pizza_size,
                           Price = pizza_size_prc)

#df_drinksmenu
drinks_id <- as.numeric(c(1,2,3))
drinks_menu <- c("Mineral Water","Coke","Diet coke")
drinks_price <- c(3,2,4)

df_drinks <- data.frame(ID = drinks_id,
                        Menu = drinks_menu,
                        Price = drinks_price)

#df_delivery type
deli_id <-as.numeric(c(1,2))
deli_menu <- c("Fast","Normal")
deli_price <- c(5,0)

df_delivery <- data.frame(ID = deli_id,
                         Menu = deli_menu,
                         Price = deli_price)
########################

  f_chatbot <- function() {
    print("Welcome to our pizza shop")
    ### Q1 Name
    print("What's your name?")
    name <- readLines("stdin",n=1)
    print(paste("Hi!", name,". Can I help you?"))
    
    ### Q2 Select Pizza
    while (TRUE) {
  print ("What would you like to order?")
  print ("This is our pizza menu")
  print (df_pizza)
  print ("Please choose menu (Enter number)")
    pizza_order <- as.numeric(readLines ("stdin",n=1))
      if (pizza_order == 1) {
        print ("You choose Ham & Crab stick") 
        break
      } else if (pizza_order == 2) {
        print ("You choose Hawaiian") 
        break
      } else if (pizza_order == 3) {
        print ("You choose Pork Deluxe")
        break
      } else if (pizza_order == 4) {
        print("You choose Veggie")
      } else if (pizza_order == 5){
        print("You choose Double Pepporoni")
      }else print ("Sorry, We don't have this number please try again.") 
  }
    ### Q3 Size Pizza
    print (paste("Which size of", pizza[pizza_order]," do you want? 1-5"))
print(df_pizza_size)
pizza_size_order <- as.numeric(readLines("stdin",n=1))

    ### Q4 How many pizza 
  print("How many pizza do you want?")
  pizza_quantity <- as.numeric(readLines("stdin", n=1))
  print(paste("Your order is", pizza[pizza_order],   pizza_size[pizza_size_order], pizza_quantity, "pcs."))
    
    ### Q5 drinks
    print ("Please select your drinks")
      while (TRUE) {
        print ("This is our drinks menu")
        print (df_drinks)
        print ("Please choose menu by type 1-2-3")
      drinks_order <- as.numeric(readLines ("stdin",n=1))
        if (drinks_order == 1) {
          print ("You choose Mineral Water")
          break
      } else if (drinks_order == 2) {
          print ("You choose Coke")
          break
      } else if (drinks_order == 3) {
          print ("You choose Diet coke")
          break
      } else print ("Sorry, We don't have this number plese try again.") 
      }

    ### Q6 How many drinks
    print ("How many drinks do you want?")
    drinks_quantity <- as.numeric(readLines("stdin", n=1))
    print (paste("Your order is", drinks_menu[drinks_order], drinks_quantity, "pcs."))

    ### Q7 Please select your order type
    print ("Please select your order type? 1-2")
    print (df_delivery)
    deli_type <- as.numeric(readLines("stdin",n=1))

#######
    pizza_price <- sum(pizza_price[pizza_order],pizza_size_prc[pizza_size_order])*pizza_quantity
    
    drinks_price <- drinks_price[drinks_order]*drinks_quantity
    
    delivery_price <- deli_price[deli_type]
#######

    ###Q8 Summary
    print (paste("This is summary of",name, "'s order"))
    
    print (paste(pizza[pizza_order], pizza_size[pizza_size_order], pizza_quantity, "pcs."))
    
    print (paste(drinks_menu[drinks_order], drinks_quantity, "pcs."))
print ("--------------------------")
print (paste("Pizza $",pizza_price))
print (paste("Drinks $",drinks_price))
print (paste("Delivery $",delivery_price))
print (paste("Total $", sum(pizza_price,drinks_price,delivery_price)))
print ("Thank you for order with us")


    
    
  }

  f_chatbot()












