-- Restaurant Owners
-- 5 Tables
-- 1x Fact, 4x Dimension
-- search google, how to add foreign key
-- write SQL 3-5 queries analyze data
-- 1x subquery/ with

--1 create & insert table orders 
-- fact
CREATE TABLE orders (
  orderId INT,
  orderDate date, 
  employeeId CHAR(4) ,
  customerId CHAR(4), 
  serviceChoiceId CHAR(2),
  menuId INT,
  FOREIGN KEY (employeeId) REFERENCES employee(employeeId),
  FOREIGN KEY (customerId) REFERENCES customer(customerId),
  FOREIGN KEY (serviceChoiceId) REFERENCES serviceChoice(serviceChoiceId),
  FOREIGN KEY (menuId) REFERENCES menu(menuId)
);
INSERT INTO orders VALUES
  (1,'2022-08-30','0002', '0001', '01', 3), 
  (2, '2022-08-30', '0002', '0001', '01', 26),
  (3, '2022-08-31', '0002', '0003', '02', 4),
  (4, '2022-08-31', '0002', '0003', '02', 8),
  (5, '2022-08-31', '0002', '0002', '03', 7),
  (6, '2022-08-31', '0002', '0003', '01', 9),
  (7, '2022-08-31', '0002', '0003', '03', 15),
  (8, '2022-08-31', '0002', '0004', '02', 20), 
  (9, '2022-09-01', '0002', '0001', '01', 26),
  (10, '2022-09-01', '0002', '0003','01', 17),
  (11, '2022-09-01', '0002', '0003','01', 23),
  (12, '2022-09-01', '0002', '0003','01', 7);

--2 table employee dim
CREATE TABLE employee (
  employeeId VARCHAR(4),
  employeeName VARCHAR(60),
  position TEXT,
  startdate date,
  PRIMARY KEY (employeeId)
);
insert INTO employee VALUES
  ('0001', 'Tom','Chief','2010-01-01'),  
  ('0002', 'Anna', 'Cashier','2010-01-01'),
  ('0003', 'John', 'Server','2015-02-17'),
  ('0004', 'Leo', 'Bus boy','2016-11-30'),
  ('0005', 'Jane', 'Server','2019-08-25'),
  ('0006', 'Tyler', 'Bus boy', '2022-04-19'),
  ('0007', 'Michael', 'Chief', '2022-07-02');

--3 table customer dim
CREATE TABLE customer (
  customerId CHAR(4) PRIMARY KEY,
  customerName TEXT,
  customerPhone VARCHAR(10),
  customerBirthday date
);
INSERT INTO customer VALUES
  ('0001', 'Pim', '081-111-1111', '1990-01-01'),
  ('0002', 'Alex', '062-222-2222', '1992-02-02'),
  ('0003', 'Lego', '053-333-3333', '1999-03-03'),
  ('0004', 'Ken', '014-444-4444', '1994-04-04');

--4 table service choice dim
CREATE TABLE serviceChoice (
  serviceChoiceId CHAR(2),
  serviceName TEXT
);
INSERT INTO serviceChoice VALUES
  ('01','Dine-in'),
  ('02','Takeaway'),
  ('03','Delivery');

--5 create & insert table menu dim
CREATE TABLE menu (
  menuId INT PRIMARY KEY,
  menuName TEXT,
  menuType CHAR(2),
  price REAL
);
INSERT INTO menu VALUES
  (1, 'Tomato Salad', '01', 119),
  (2, 'Chicken Salad', '01', 149),
  (3, 'Corn Soup', '02', 89),
  (4, 'French Onion', '02', 59),
  (5, 'Tomato Soup', '02', 80),
  (6, 'German sausage and chips','03', 162.5),
  (7, 'Grilled fish and potatoes','03', 156.25),
  (8, 'Italian cheese and tomato pizza','03', 121.25),
  (9, 'Thai chicken and rice','03', 135),
  (10, 'Vegetable pasta','03', 250.25),
  (11, 'Roast chicken and potatoes','03', 200),
  (12, 'Shrimp Porridge', '03', 159.25),
  (13, 'Chicken Porridge', '03', 100),
  (14, 'Pan Fried Egg', '03', 119.50),
  (15, 'Cheese Burger', '04', 80),
  (16, 'Vegetable omelette', '04', 45),
  (17, 'Cheese and tomato sandwich', '04', 60),
  (18, 'Chicken sandwich', '04', 65.75),
  (19, 'Fruit salad and cream', '05', 70),
  (20, 'Ice cream', '05', 20),
  (21, 'Lemon cake', '05', 95),
  (22, 'Chocolate cake', '05', 95),
  (23, 'Mineral water', '06', 30),
  (24, 'Fresh orange juice', '06', 60),
  (25, 'Soft drinks', '06', 40),
  (26, 'English Tea', '06', 50),
  (27, 'Irish Cream Coffee', '06', 45);

--6 table menuType
CREATE TABLE DimMenuType (
  menuType CHAR(2),
  menuTypeName TEXT
);
INSERT INTO DimMenuType VALUES
  ('01', 'salad'),
  ('02', 'soup'),
  ('03', 'main courses'),
  ('04', 'snacks'),
  ('05', 'desserts'),
  ('06', 'drinks');
  





-- sqlite command
.mode markdown
.header on

--1 with for select bill
  
WITH sub AS (
    SELECT 
      orders.orderId,
      orders.orderdate,
      menu.menuName,
      menu.price,
      serviceChoice.serviceName,
      customer.customerName

    FROM orders
    JOIN customer ON customer.customerId = orders.customerId
    JOIN menu ON menu.menuId = orders.menuId  
    JOIN serviceChoice ON serviceChoice.serviceChoiceId = orders.serviceChoiceId 
)

-- item & totalprice for 2022-08-30 (Pim)
SELECT 
    orderdate,
    menuName,
    price,
    customerName
  FROM sub
  WHERE customerName LIKE 'P%' and
  STRFTIME('%d',orderdate) = '30'

/*

SELECT 
  COUNT(*) Items,
  SUM(price) Total  
FROM (
  SELECT 
    orderdate,
    menuName,
    price,
    customerName
  FROM sub
  WHERE customerName LIKE 'P%' and
  STRFTIME('%d',orderdate) = '30' )

*/
  
--Tops 5 most expensive in main courses 
/*
  select 
  menu.menuName,
  menu.price,
  DimMenuType.menuTypeName
from menu
JOIN DimMenuType ON menu.menuType = DimMenuType.menuType
WHERE menuTypeName = 'main courses'
order by price desc limit 5;
*/

--query look at subscriber
 /*
SELECT 
count(*) subscriber,
serviceChoice.serviceName
FROM orders
JOIN serviceChoice ON orders.serviceChoiceId = serviceChoice.serviceChoiceId
GROUP BY serviceName ; 
*/

--query find new employee
/*
SELECT 
  employeeName,
  startdate,
  CASE
    WHEN STRFTIME('%Y',startdate) >= '2020' THEN 'New Employee'
    ELSE 'old Employee'
  END 
FROM employee;
*/


